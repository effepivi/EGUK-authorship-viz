import { select, 
        csv,
        scaleLinear,
        max,
        scaleBand, 
        axisLeft, 
        axisBottom } from 'd3';

const svg = select('svg');

const render = data => {
	const width = +svg.attr('width');
	const height = +svg.attr('height');
	const margin = { top: 20, right: 40, bottom: 20, left: 100};

  
  const xScale = scaleLinear()
  		.domain([0, max(data, d => d.NumberofContributions)])
  		.range([0, innerWidth]);
  
  	const yScale = scaleBand()
    	.domain(data.map(d => d.Author))
    	.range([0, innerHeight])
  		.padding (0.1);
  

  const g = svg.append('g')
  .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  g.append('g').call(axisLeft(yScale));
  g.append('g').call(axisBottom(xScale));
  
  
  g.selectAll('rect').data(data)
  		.enter().append('rect')
  		.attr('y', d => yScale(d.Author))
  		.attr('width', d => xScale(d.NumberofContributions))
  		.attr('height', yScale.bandwidth());
};

csv('data.csv').then(data => {
            data.forEach(d => {
    d.NumberofContributions = +d.NumberofContributions * 1000;
            });
  	render(data);
});
                     